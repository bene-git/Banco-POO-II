/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Funcionario;

import Gerente.ExGerente;
import Gerente.GerCadastro;
import Menu.MenuAdm;
import Menu.MenuGerente;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Benedito Rodrigo
 */
public class Funcionario {
    
    private static String logFun = "";
    private static String senFun = "";

    public static String getLogFun() {
        return logFun;
    }

    public static void setLogFun(String logFun) {
        Funcionario.logFun = logFun;
    }

    public static String getSenFun() {
        return senFun;
    }

    public static void setSenFun(String senFun) {
        Funcionario.senFun = senFun;
    }
    
    public static void cadFuncionario(String p1, String p2, String p3, float p4, String p5) throws IOException{
        File arquivo = new File("DadosFuncionario/"+p2+".txt");
        boolean verifica = arquivo.exists();
        if(verifica==true){
            JOptionPane.showMessageDialog(null, "CPF Exist!");
        }else{
            arquivo.createNewFile();
            arquivo.mkdir();
            FileWriter fw = new FileWriter(arquivo);
            //FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(p2+"|");
            bw.write(p1+"|");
            bw.write(p3+"|");
            bw.write(String.valueOf(p4)+"|");
            bw.write(p5+"|");
            bw.newLine();
            bw.close();
            fw.close();
            JOptionPane.showMessageDialog(null, "Funcionario Cadastrado", "OK", JOptionPane.INFORMATION_MESSAGE);
            MenuGerente mena = new MenuGerente();
            FunCadastro gera = new FunCadastro();
            mena.setVisible(true);
            mena.setLocationRelativeTo(null);
            gera.dispose();
        }
    }
    
    public static void atuaFuncionario(String p1, String p2, String p3, float p4, String p5) throws IOException{
        File arquivo = new File("DadosFuncionario/"+p2+".txt");
        boolean verifica = arquivo.exists();

            FileWriter fw = new FileWriter(arquivo);
            //FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(p2+"|");
            bw.write(p1+"|");
            bw.write(p3+"|");
            bw.write(String.valueOf(p4)+"|");
            bw.write(p5+"|");
            bw.newLine();
            bw.close();
            fw.close();
            JOptionPane.showMessageDialog(null, "Funcionario Atualizado", "OK", JOptionPane.INFORMATION_MESSAGE);
            MenuGerente mena = new MenuGerente();
            FunCadastro gera = new FunCadastro();
            mena.setVisible(true);
            mena.setLocationRelativeTo(null);
            gera.dispose();
    }
    
    public static String verificaCPF(String cpf) throws IOException{
        
        String retorno = "0x2";
        
        File arquivo = new File("DadosFuncionario/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==true){
            retorno = cpf;
        } else {
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
        
        return retorno;
    }
    
    public static boolean verCPFExiste(String cpf) throws IOException{
        
        File arquivo = new File("DadosFuncionario/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==false){
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
        
        return verifica;
    }
    
    public static String recuperarTudo(String cpf) throws IOException{
        
        File arquivo = new File("DadosFuncionario/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        ExGerente eg = new ExGerente();
        
        int i = 0, cont = 0;
        String reg = "";
        String cpp = "";
        
        if(verifica==true){
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            while(br.ready()){
                String linha = br.readLine();
                for(i=0;i<linha.length();i++){
                    if(linha.substring(i, i+1).equals("|")){
                        cont++;   
                    }
                    if(cont==0){
                        cpp += linha.substring(i, i+1);
                    }
                }
                if(cpp.equals(cpf)){
                    reg = linha;
                    break;
                }
                cont = 0;
            }
            fr.close();
            br.close();
        }
        return reg;
    }
    
    public static String setarExc(String cpf) throws IOException{
        
        File arquivo = new File("DadosFuncionario/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        ExGerente eg = new ExGerente();
        
        int i = 0, cont = 0;
        String reg = "";
        String cpp = "";
        
        if(verifica==true){
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            while(br.ready()){
                String linha = br.readLine();
                for(i=0;i<linha.length();i++){
                    if(linha.substring(i, i+1).equals("|")){
                        cont++;
                        
                    }
                    if(cont==0){
                        cpp += linha.substring(i, i+1);
                    }
                    if(cont==1){
                        reg += linha.substring(i, i+1);
                    }
                }
                if(cpp.equals(cpf)){
                    break;
                }
                cont = 0;
            }
            fr.close();
            br.close();
        }
        return reg.substring(1, reg.length());
    }
    
    public static void excluirFun(String cpf) throws IOException{
        
        File arquivo = new File("DadosFuncionario/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==true){
            arquivo.delete();
            JOptionPane.showMessageDialog(null, "Funcionário Excluído", "DELTE Fun", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
    }
    
    public static void guardaLogFun(String cpf) throws IOException{
        int p = 0;
        
        String tudo = Funcionario.recuperarTudo(cpf);
        String gamb = "";
        String [] vet;
        vet = new String[6];
        
        for(int i=0;i<tudo.length();i++){
            gamb = gamb + tudo.substring(i, i+1);
            if(tudo.substring(i, i+1).equals("|")||i==tudo.length()-1){
                vet[p] = gamb;
                gamb = "";
                p++;
            }
        }
        Funcionario f = new Funcionario();
        f.setLogFun(vet[0].substring(0, vet[0].length()-1));
        f.setSenFun(vet[2].substring(0, vet[2].length()-1));
    }
}
