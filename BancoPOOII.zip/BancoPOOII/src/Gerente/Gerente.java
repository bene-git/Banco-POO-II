package Gerente;

import Menu.MenuAdm;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

public class Gerente {
    
    private static String logGer = "";
    private static String senGer = "";

    public String getLogGer() {
        return logGer;
    }

    public void setLogGer(String logGer) {
        this.logGer = logGer;
    }

    public String getSenGer() {
        return senGer;
    }

    public void setSenGer(String senGer) {
        this.senGer = senGer;
    }
    
    public static void cadGerente(String n, String c, String sen, String t, float s, String f) throws IOException{
        File arquivo = new File("DadosGerente/"+c+".txt");
        boolean verifica = arquivo.exists();
        if(verifica==true){
            JOptionPane.showMessageDialog(null, "CPF Exist!");
        }else{
            arquivo.createNewFile();
            arquivo.mkdir();
            FileWriter fw = new FileWriter(arquivo);
            //FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(c+"|");
            bw.write(n+"|");
            bw.write(sen+"|");
            bw.write(t+"|");
            bw.write(String.valueOf(s)+"|");
            bw.write(f);
            bw.newLine();
            bw.close();
            fw.close();
            JOptionPane.showMessageDialog(null, "Gerente Cadastrado", "OK", JOptionPane.INFORMATION_MESSAGE);
            MenuAdm mena = new MenuAdm();
            GerCadastro gera = new GerCadastro();
            mena.setVisible(true);
            mena.setLocationRelativeTo(null);
            gera.dispose();
        }
    }
    
    //fazer essa
    public static void AltGerente(String n, String c, String sen, String t, float s, String f) throws IOException{
        File arquivo = new File("DadosGerente/"+c+".txt");
        boolean verifica = arquivo.exists();
        
        FileWriter fw = new FileWriter(arquivo);
        //FileWriter fw = new FileWriter(arquivo, true);
        BufferedWriter bw = new BufferedWriter(fw); 
        bw.write(c+"|");
        bw.write(n+"|");
        bw.write(sen+"|");
        bw.write(t+"|");
        bw.write(String.valueOf(s)+"|");
        bw.write(f);
        bw.newLine();
        bw.close();
        fw.close();
        JOptionPane.showMessageDialog(null, "Gerente Atualizado", "OK", JOptionPane.INFORMATION_MESSAGE);
        MenuAdm mena = new MenuAdm();
        GerAlterar gera = new GerAlterar();
        mena.setVisible(true);
        mena.setLocationRelativeTo(null);
        gera.dispose();
    }
    
    public static String verificaCPFAlt(String cpf) throws IOException{
        
        String retorno = "0x2";
        
        File arquivo = new File("DadosGerente/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==true){
            retorno = cpf;
        } else {
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
        
        return retorno;
    }
    
    public static void excluirGer(String cpf) throws IOException{
        
        File arquivo = new File("DadosGerente/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==true){
            arquivo.delete();
            JOptionPane.showMessageDialog(null, "Gerente Excluído", "DELTE Ger", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
    }
    
    public static String setarExc(String cpf) throws IOException{
        
        File arquivo = new File("DadosGerente/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        ExGerente eg = new ExGerente();
        
        int i = 0, cont = 0;
        String reg = "";
        String cpp = "";
        
        if(verifica==true){
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            while(br.ready()){
                String linha = br.readLine();
                for(i=0;i<linha.length();i++){
                    if(linha.substring(i, i+1).equals("|")){
                        cont++;
                        
                    }
                    if(cont==0){
                        cpp += linha.substring(i, i+1);
                    }
                    if(cont==1){
                        reg += linha.substring(i, i+1);
                    }
                }
                if(cpp.equals(cpf)){
                    break;
                }
                cont = 0;
            }
            fr.close();
            br.close();
        }
        return reg.substring(1, reg.length());
    }
    
    public static String recuperarTudo(String cpf) throws IOException{
        
        File arquivo = new File("DadosGerente/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        ExGerente eg = new ExGerente();
        
        int i = 0, cont = 0;
        String reg = "";
        String cpp = "";
        
        if(verifica==true){
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            while(br.ready()){
                String linha = br.readLine();
                for(i=0;i<linha.length();i++){
                    if(linha.substring(i, i+1).equals("|")){
                        cont++;   
                    }
                    if(cont==0){
                        cpp += linha.substring(i, i+1);
                    }
                }
                if(cpp.equals(cpf)){
                    reg = linha;
                    break;
                }
                cont = 0;
            }
            fr.close();
            br.close();
        }
        return reg;
    }
    
    public static boolean verCPFExiste(String cpf) throws IOException{
        
        File arquivo = new File("DadosGerente/"+cpf+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==false){
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
        
        return verifica;
    }
    
    public static void guardaLogGerente(String cpf) throws IOException{
        
        int p = 0;
        
        String tudo = Gerente.recuperarTudo(cpf);
        String gamb = "";
        String [] vet;
        vet = new String[6];
        
        for(int i=0;i<tudo.length();i++){
            gamb = gamb + tudo.substring(i, i+1);
            if(tudo.substring(i, i+1).equals("|")||i==tudo.length()-1){
                vet[p] = gamb;
                gamb = "";
                p++;
            }
        }
        Gerente g = new Gerente();
        g.setLogGer(vet[0].substring(0, vet[0].length()-1));
        g.setSenGer(vet[2].substring(0, vet[2].length()-1));
    }
    
    String cpfGuardado;

    public String getCpfGuardado() {
        return cpfGuardado;
    }

    public void setCpfGuardado(String cpfGuardado) {
        this.cpfGuardado = cpfGuardado;
    }
}
