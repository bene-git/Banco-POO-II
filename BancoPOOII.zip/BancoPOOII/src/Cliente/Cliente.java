package Cliente;

import Funcionario.FunCadastro;
import Gerente.ExGerente;
import Menu.MenuGerente;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Cliente {
    public static void cadFuncionario(String p1, String p2, String p3, String p4, String p5, String p6) throws IOException{
        File arquivo = new File("DadosCliente/"+p3+".txt");
        boolean verifica = arquivo.exists();
        if(verifica==true){
            JOptionPane.showMessageDialog(null, "CPF Exist!");
        }else{
            arquivo.createNewFile();
            arquivo.mkdir();
            FileWriter fw = new FileWriter(arquivo);
            //FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(p3+"|");
            bw.write(p1+"|");
            bw.write(p2+"|");
            bw.write(p4+"|");
            bw.write(p5+"|");
            bw.write(p6+"|");
            bw.newLine();
            bw.close();
            fw.close();
            JOptionPane.showMessageDialog(null, "Cliente Cadastrado", "OK", JOptionPane.INFORMATION_MESSAGE);
            MenuGerente mena = new MenuGerente();
            ClientCadastro gera = new ClientCadastro();
            mena.setVisible(true);
            mena.setLocationRelativeTo(null);
            gera.dispose();
        }
    }
    
    public static void altC(String p1, String p2, String p3, String p4, String p5, String p6) throws IOException{
        File arquivo = new File("DadosCliente/"+p3+".txt");
        boolean verifica = arquivo.exists();
            FileWriter fw = new FileWriter(arquivo);
            //FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(p3+"|");
            bw.write(p1+"|");
            bw.write(p2+"|");
            bw.write(p4+"|");
            bw.write(p5+"|");
            bw.write(p6+"|");
            bw.newLine();
            bw.close();
            fw.close();
            JOptionPane.showMessageDialog(null, "Cliente Alterado", "OK", JOptionPane.INFORMATION_MESSAGE);
            MenuGerente mena = new MenuGerente();
            ClientCadastro gera = new ClientCadastro();
            mena.setVisible(true);
            mena.setLocationRelativeTo(null);
            gera.dispose();
    }
    
    public static void altCDep(String p1, String p2, String p3, String p4, String p5, String p6) throws IOException{
        File arquivo = new File("DadosCliente/"+p3+".txt");
        boolean verifica = arquivo.exists();
            FileWriter fw = new FileWriter(arquivo);
            //FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(p3+"|");
            bw.write(p1+"|");
            bw.write(p2+"|");
            bw.write(p4+"|");
            bw.write(p5+"|");
            bw.write(p6+"|");
            bw.newLine();
            bw.close();
            fw.close();
    }
    
    public static void altCPag(String p1, String p2, String p3, String p4, String p5, String p6) throws IOException{
        File arquivo = new File("DadosCliente/"+p3+".txt");
        boolean verifica = arquivo.exists();
            FileWriter fw = new FileWriter(arquivo);
            //FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw); 
            bw.write(p3+"|");
            bw.write(p1+"|");
            bw.write(p2+"|");
            bw.write(p4+"|");
            bw.write(p5+"|");
            bw.write(p6+"|");
            bw.newLine();
            bw.close();
            fw.close();
            JOptionPane.showMessageDialog(null, "Boleto Pago!", "OK", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static boolean verCPFExiste(String con) throws IOException{
        
        File arquivo = new File("DadosCliente/"+con+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==false){
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
        
        return verifica;
    }
    
    public static boolean verTranExist(String con) throws IOException{
        
        File arquivo = new File("DadosCliente/"+con+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==false){
            JOptionPane.showMessageDialog(null, "Destino Não Existe!", "DESTINATION NOT EXIST", JOptionPane.ERROR);
        }
        
        return verifica;
    }
    
    public static String recuperarTudo(String conta) throws IOException{
        
        File arquivo = new File("DadosCliente/"+conta+".txt");
        boolean verifica = arquivo.exists();
        
        ExGerente eg = new ExGerente();
        
        int i = 0, cont = 0;
        String reg = "";
        String cpp = "";
        
        if(verifica==true){
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            while(br.ready()){
                String linha = br.readLine();
                for(i=0;i<linha.length();i++){
                    if(linha.substring(i, i+1).equals("|")){
                        cont++;   
                    }
                    if(cont==0){
                        cpp += linha.substring(i, i+1);
                    }
                }
                if(cpp.equals(conta)){
                    reg = linha;
                    break;
                }
                cont = 0;
            }
            fr.close();
            br.close();
        }
        return reg;
    }
    
    public static String setarExc(String conta) throws IOException{
        
        File arquivo = new File("DadosCliente/"+conta+".txt");
        boolean verifica = arquivo.exists();
        
        ExGerente eg = new ExGerente();
        
        int i = 0, cont = 0;
        String reg = "";
        String cpp = "";
        
        if(verifica==true){
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            while(br.ready()){
                String linha = br.readLine();
                for(i=0;i<linha.length();i++){
                    if(linha.substring(i, i+1).equals("|")){
                        cont++;
                        
                    }
                    if(cont==0){
                        cpp += linha.substring(i, i+1);
                    }
                    if(cont==1){
                        reg += linha.substring(i, i+1);
                    }
                }
                if(cpp.equals(conta)){
                    break;
                }
                cont = 0;
            }
            fr.close();
            br.close();
        }
        return reg.substring(1, reg.length());
    }
    
    public static void excluirClient(String cont) throws IOException{
        
        File arquivo = new File("DadosCliente/"+cont+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==true){
            arquivo.delete();
            JOptionPane.showMessageDialog(null, "Cliente Excluído", "DELTE Cliente", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
    }
    
    public static String verificaConta(String conta) throws IOException{
        
        String retorno = "0x2";
        
        File arquivo = new File("DadosCliente/"+conta+".txt");
        boolean verifica = arquivo.exists();
        
        if(verifica==true){
            retorno = conta;
        } else {
            JOptionPane.showMessageDialog(null, "CPF not Exist", "CPF NOT", JOptionPane.ERROR);
        }
        
        return retorno;
    }
    
    public static String guardarSaldo(String conta){
        
        String saldo = "0.0";
        
        String cont  = conta;
        
        boolean vrf = false;
        
        String tudo = "";
        
        try {
            vrf = Cliente.verCPFExiste(cont);
        } catch (IOException ex) {
            Logger.getLogger(PedirRec.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            tudo = Cliente.recuperarTudo(cont);
        } catch (IOException ex) {
            Logger.getLogger(PedirRec.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String gamb = "";
        int p = 0;
        String [] vet;
        vet = new String[6];
        for(int i=0;i<tudo.length();i++){
            gamb = gamb + tudo.substring(i, i+1);
            if(tudo.substring(i, i+1).equals("|")||i==tudo.length()-1){
                vet[p] = gamb;
                gamb = "";
                p++;
            }
        }
        
        saldo = vet[4].substring(0, vet[4].length()-1);
        
        return saldo;
    } 
}
