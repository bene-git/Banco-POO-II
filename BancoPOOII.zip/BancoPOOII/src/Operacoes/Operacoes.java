package Operacoes;

import Cliente.Cliente;
import java.io.IOException;

public class Operacoes {
    
    static Cliente c = new Cliente();
    static Saldo s = new Saldo();
    
    private static String logC = "";
    private static String senC = "";
    
    private static String nome = "";
    private static String rend = "";
    private static String sald = "";
    private static String cpf = "";

    public static String getNome() {
        return nome;
    }

    public static void setNome(String nome) {
        Operacoes.nome = nome;
    }

    public static String getRend() {
        return rend;
    }

    public static void setRend(String rend) {
        Operacoes.rend = rend;
    }

    public static String getSald() {
        return sald;
    }

    public static void setSald(String saldo) {
        Operacoes.sald = saldo;
    }

    public static String getCpf() {
        return cpf;
    }

    public static void setCpf(String cpf) {
        Operacoes.cpf = cpf;
    }
    
    

    public static String getSenC() {
        return senC;
    }

    public static void setSenC(String senC) {
        Operacoes.senC = senC;
    }

    public static String getLogC() {
        return logC;
    }

    public static void setLogC(String logC) {
        Operacoes.logC = logC;
    }
    
    public static void verSaldo(String cont) throws IOException{
        
        String tudo = c.recuperarTudo(cont);
        
        String gamb = "";
        int p = 0;
        String [] vet;
        vet = new String[6];
        for(int i=0;i<tudo.length();i++){
            gamb = gamb + tudo.substring(i, i+1);
            if(tudo.substring(i, i+1).equals("|")||i==tudo.length()-1){
                vet[p] = gamb;
                gamb = "";
                p++;
            }
        }
        Operacoes.setSald(vet[4].substring(0, vet[4].length()-1));
        Operacoes.setNome(vet[1].substring(0, vet[1].length()-1));
        Operacoes.setLogC(vet[0].substring(0, vet[0].length()-1));
    }
    
    public static void guardarTudo(String cont) throws IOException{
        
        String tudo = c.recuperarTudo(cont);
        
        String gamb = "";
        int p = 0;
        String [] vet;
        vet = new String[6];
        for(int i=0;i<tudo.length();i++){
            gamb = gamb + tudo.substring(i, i+1);
            if(tudo.substring(i, i+1).equals("|")||i==tudo.length()-1){
                vet[p] = gamb;
                gamb = "";
                p++;
            }
        }
        
        Operacoes.setLogC(vet[0].substring(0, vet[0].length()-1));
        Operacoes.setNome(vet[1].substring(0, vet[1].length()-1));
        Operacoes.setCpf(vet[2].substring(0, vet[2].length()-1));
        Operacoes.setSenC(vet[3].substring(0, vet[3].length()-1));
        Operacoes.setSald(vet[4].substring(0, vet[4].length()-1));
        Operacoes.setRend(vet[5].substring(0, vet[5].length()-1));
    }
    
    public static void guardaLog(String cont) throws IOException{
        
        String tudo = c.recuperarTudo(cont);
        
        String gamb = "";
        int p = 0;
        String [] vet;
        vet = new String[6];
        for(int i=0;i<tudo.length();i++){
            gamb = gamb + tudo.substring(i, i+1);
            if(tudo.substring(i, i+1).equals("|")||i==tudo.length()-1){
                vet[p] = gamb;
                gamb = "";
                p++;
            }
        }
        Operacoes.setLogC(vet[0].substring(0, vet[0].length()-1));
        Operacoes.setSenC(vet[3].substring(0, vet[3].length()-1));
    }
}
