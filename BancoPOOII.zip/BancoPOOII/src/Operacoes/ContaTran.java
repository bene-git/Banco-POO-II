package Operacoes;

import Cliente.Cliente;
import java.io.IOException;

public class ContaTran {
    
    static Cliente c = new Cliente();
    
    private static String nm = "";
    private static String cf = "";
    private static String cn = "";
    private static String ln = "";
    private static String sl = "";
    private static String tr = "";

    public static String getNm() {
        return nm;
    }

    public static void setNm(String nm) {
        ContaTran.nm = nm;
    }

    public static String getCf() {
        return cf;
    }

    public static void setCf(String cf) {
        ContaTran.cf = cf;
    }

    public static String getCn() {
        return cn;
    }

    public static void setCn(String cn) {
        ContaTran.cn = cn;
    }

    public static String getLn() {
        return ln;
    }

    public static void setLn(String ln) {
        ContaTran.ln = ln;
    }

    public static String getSl() {
        return sl;
    }

    public static void setSl(String sl) {
        ContaTran.sl = sl;
    }

    public static String getTr() {
        return tr;
    }

    public static void setTr(String tr) {
        ContaTran.tr = tr;
    }
    
    public static void pegaTudo(String cont) throws IOException{
        
        String tudo = c.recuperarTudo(cont);
        
        String gamb = "";
        int p = 0;
        String [] vet;
        vet = new String[6];
        for(int i=0;i<tudo.length();i++){
            gamb = gamb + tudo.substring(i, i+1);
            if(tudo.substring(i, i+1).equals("|")||i==tudo.length()-1){
                vet[p] = gamb;
                gamb = "";
                p++;
            }
        }
        
        ContaTran.setNm(vet[1].substring(0, vet[1].length()-1));
        ContaTran.setCf(vet[2].substring(0, vet[2].length()-1));
        ContaTran.setCn(vet[0].substring(0, vet[0].length()-1));
        ContaTran.setLn(vet[3].substring(0, vet[3].length()-1));
        ContaTran.setSl(vet[4].substring(0, vet[4].length()-1));
        ContaTran.setTr(vet[5].substring(0, vet[5].length()-1));
    }
}
