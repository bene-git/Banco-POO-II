package bancopooii;

import Menu.LoginAdm;
import Menu.MenuAdm;
import Menu.MenuGerente;
import Menu.MenuPrin;
import javax.swing.JFrame;

public class BancoPOOII {

    public static void main(String[] args) {
        MenuPrin menuP = new MenuPrin();
        menuP.setVisible(true);
        menuP.setLocationRelativeTo(null);
    }
    
}
